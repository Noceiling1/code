from ultralytics import YOLO

# Load a model
model = YOLO("")  #

# # Use the model
# model.predict(source="/gemini/code/Yolov8_with_DCNv3-master/crack", save=True, save_txt=True, conf=0.1, name='预测8n(13层检测头,ak两条)')  # train the model


results = model("",name="")  
