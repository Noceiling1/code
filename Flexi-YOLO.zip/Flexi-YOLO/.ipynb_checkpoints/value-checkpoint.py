#coding: utf-8
from ultralytics import YOLO


if __name__ == '__main__':
    #加载训练好的模型
    model = YOLO(r"/gemini/code/Yolov8_with_DCNv3-master/runs/detect/8n(检测头共享权重)2/weights/best.pt")
    # 对验证集进行评估
    metrics = model.val(data = r'/gemini/code/Yolov8_with_DCNv3-master/Data/data.yaml',batch=1)

    # model = YOLO(r"/gemini/code/Yolov8_with_DCNv3-master/runs/best/ylov8n-416-150.pt")
    # metrics = model.val(data = r'/gemini/code/ultralytics-main/ultralytics-main/Data/data.yaml')