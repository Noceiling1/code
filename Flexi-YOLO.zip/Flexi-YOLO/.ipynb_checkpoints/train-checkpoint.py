from ultralytics import YOLO

# Load a model
# model = YOLO("yolov8n.yaml")  # build a new model from scratch
model = YOLO("yolov8n-AKConv+DCNV+GAM.yaml")  # build a new model from scratch
# Use the model
model.train(data="/gemini/code/Yolov8_with_DCNv3-master/Data/data.yaml", epochs=175,imgsz=416, batch=64, device=0,patience=0,name="8n(检测头共享权重)")  # train the model
# metrics = model.val()  # evaluate model performance on the validation set


