from ultralytics import YOLO

# Load a model
model = YOLO("//gemini/code/Yolov8_with_DCNv3-master/runs/detect/8n(13层检测头,ak两条)/weights/best.pt")  #

# # Use the model
# model.predict(source="/gemini/code/Yolov8_with_DCNv3-master/crack", save=True, save_txt=True, conf=0.1, name='预测8n(13层检测头,ak两条)')  # train the model


results = model("/gemini/code/Yolov8_with_DCNv3-master/crack/001.jpg", visualize=True,name="可视化")  # 要预测图片路径和使用可视化
