#coding: utf-8
from ultralytics import YOLO


if __name__ == '__main__':
    #加载训练好的模型
    model = YOLO(r"")
    # 对验证集进行评估
    metrics = model.predict("", save=True, device=0)